CREATE VIEW domain_count AS
  SELECT top_urls.domain,
    count(*) AS count
   FROM top_urls
  GROUP BY top_urls.domain
  ORDER BY (count(*)) DESC;

