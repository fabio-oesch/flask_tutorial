CREATE VIEW count_tlds AS
  SELECT top_urls.tld,
    top_urls.tld_second,
    count(*) AS tld_count
   FROM top_urls
  GROUP BY top_urls.tld, top_urls.tld_second;

